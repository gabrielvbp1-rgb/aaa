# Checklist de conteúdo (PRELIMINAR — nada verificado ainda)
Colunas: Pesq | Verif | Model | Textur | Impl | Test. Lista abaixo é ponto de partida e será ampliada/corrigida na pesquisa.

## Bronze (anime clássico) — a confirmar contra fontes
- [ ] Seiya — Pegasus
- [ ] Shiryu — Dragon
- [ ] Hyoga — Cygnus
- [ ] Shun — Andromeda
- [ ] Ikki — Phoenix
- [ ] Jabu — Unicorn
- [ ] Geki — Bear
- [ ] Nachi — Wolf
- [ ] Ban — Lionet
- [ ] Ichi — Hydra
- [ ] (outros Bronze secundários: a pesquisar)

## Prata — lista completa A PESQUISAR (não será preenchida de memória)
- [ ] Algol — Perseus (necessário p/ Fase 5)
- [ ] demais: pendente

## Ouro (ordem fixa, 12) — nomes dos Cavaleiros a verificar na Fase 7
Áries, Touro, Gêmeos, Câncer, Leão, Virgem, Libra, Escorpião, Sagitário, Capricórnio, Aquário, Peixes

## NPCs/Bosses: Athena, Tatsumi, Kiki, Cassios, Algol, treinadores, Cavaleiros Negros
## Técnicas: catalogar por personagem durante a pesquisa
