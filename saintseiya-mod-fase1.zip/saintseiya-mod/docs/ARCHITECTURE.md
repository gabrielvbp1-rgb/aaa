# Saint Seiya Mod — Arquitetura (Fase 0)
Plataforma: **Forge 1.12.2 / Java 8** (mod id: `saintseiya`, pacote base `com.saintseiya`)

## 1. Estrutura de pastas
```
saintseiya-mod/
├─ build.gradle / gradle.properties / mcmod.info
├─ src/main/java/com/saintseiya/
│  ├─ SaintSeiyaMod.java            # entrada, @Mod
│  ├─ proxy/ (CommonProxy, ClientProxy)
│  ├─ config/                       # ModConfig (todos os números balanceáveis)
│  ├─ registry/                     # ModItems, ModBlocks, ModEntities, ModSounds, ModKeybinds
│  ├─ data/                         # BASE DE DADOS (Character, Technique, Cloth, Constellation + loaders JSON)
│  ├─ capability/                   # PlayerSaintData (constelação, signo, patente, atributos, cosmo, V1/V2)
│  ├─ network/                      # SimpleNetworkWrapper + packets
│  ├─ attribute/                    # Força/Agilidade/Defesa/Vitalidade/Cosmo -> modificadores
│  ├─ cosmo/                        # CosmoManager, regen, 7º Sentido
│  ├─ skill/                        # SkillTree, SkillSlot, hotbar lateral, TechniqueExecutor
│  ├─ technique/                    # 1 classe por comportamento (projétil, corrente, rajada, barreira...)
│  ├─ armor/                        # ItemSaintCloth, ClothRenderLayer, essência, reparo, evolução V1->V2
│  ├─ pandora/                      # ItemPandoraBox, BlockPandoraBox(TileEntity), animação de montagem
│  ├─ quest/                        # QuestManager, Quest, patentes (Bronze/Prata/Ouro)
│  ├─ entity/                       # npc/ (Athena, Tatsumi, Kiki, treinadores), boss/ (Cassios, Algol, 12 Ouro), mob/ (Cav. Negros)
│  ├─ ai/                           # IA por boss (uma classe por Cavaleiro de Ouro)
│  ├─ world/                        # gen/ (StructureGenerator das 3 estruturas), SaintWorldData (posições, 1x por mundo)
│  ├─ sanctuary/                    # TwelveHousesManager, ordem obrigatória, spawn sob demanda
│  ├─ goldseat/                     # posto de Ouro (jogador ocupa casa), convite aceitar/recusar, fallback NPC
│  ├─ compass/                      # ItemSaintCompass + GUI
│  ├─ client/                       # gui/ (iniciação, status V, skill tree, compass), render/, particle/, fx/
│  └─ util/
├─ src/main/resources/assets/saintseiya/
│  ├─ data/{characters,techniques,cloths,constellations}/*.json
│  ├─ models/ textures/ sounds/ lang/ (pt_br, en_us) structures/
└─ docs/ (ARCHITECTURE, PROGRESS, CHECKLIST, data_samples)
```

## 2. Decisões-chave
- **Dados do jogador:** Forge Capability `PlayerSaintData` (persistente, sincronizada por packet).
- **Dados do mundo:** `WorldSavedData` com posição das 3 estruturas, ocupantes dos postos de Ouro, e se a estrutura já foi gerada (garante "1x por mundo" e distância mínima configurável).
- **Conteúdo orientado a dados:** Cavaleiros, armaduras e técnicas são JSON. Novo Cavaleiro = novo arquivo, sem recompilar sistema.
- **Técnicas:** JSON define parâmetros; o campo `behavior` aponta para uma classe em `technique/` (ex.: `RAPID_BARRAGE`, `CHAIN`, `METEOR_SHOWER`, `BARRIER`). Cada técnica tem identidade própria via `visual_effect`/`sound`/`animation`.
- **Armaduras:** Bronze V1 ≈ Netherite em durabilidade (config), Prata > V1, V2 > Prata. Quebrou = item `cloth_essence` (guarda constelação + peça). Evolução V2 exige 1 sangue de Ouro **por peça**.
- **Render das armaduras:** modelos ModelBiped/ModelBase exportados do Blockbench, aplicados via layer de render (não só texturas planas). Biblioteca de animação (ex.: GeckoLib p/ 1.12.2) a confirmar antes da Fase 3.
- **Multiplayer:** servidor autoritativo (cosmo, dano, quests, posto de Ouro). Cliente só renderiza e envia intenções.
- **Posto de Ouro:** ao chegar na casa X, `TwelveHousesManager` consulta `GoldSeatManager`; se o ocupante estiver online, envia convite (aceitar/recusar, com timeout configurável). Aceitou -> teleporta ambos. Recusou/offline/timeout -> spawna NPC.
- **Config:** nível do Cosmo (30), XP, custos, danos, cooldowns, drops (10% sangue / 5% Pandora Box), nº de missões (80 p/ Prata), distância mínima entre estruturas, duração/consumo do 7º Sentido, atributos.
- **Teclas:** V = status, G = 7º Sentido (toggle), hotbar de técnicas configurável.

## 3. Sistemas e fases
| Sistema | Fase |
|---|---|
| Projeto, menu de iniciação, constelação/signo | 1 |
| Atributos, Cosmo, barra, menu V, skill tree | 2 |
| Pandora Box, Bronze V1, Cassios, Athena, Coliseu | 3 |
| Missões, Tatsumi, patentes, Cav. Negros, dungeons | 4 |
| Prata, Algol | 5 |
| Kiki, Torre de Jamiel, pó estelar, reparo, V2 | 6 |
| Santuário, 12 Casas, Ouro, sangue | 7 |
| Patente Ouro, 7º Sentido, desafio do signo | 8 |
| Posto de Ouro multiplayer, balanceamento, FX, otimização | 9 |
