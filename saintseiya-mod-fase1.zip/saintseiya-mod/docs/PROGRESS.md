# Progresso
## Implementado
- Fase 0: arquitetura, dados de amostra, checklist
- Fase 1 (parcial, NÃO COMPILADO/TESTADO): mod base, aba criativa "Saint Seiya", Bússola (placeholder),
  capability do jogador (constelação/signo/escolha), rede cliente<->servidor, menu de iniciação
  (abre quando não escolheu; ESC bloqueado; servidor valida escolha única)
## Falta na Fase 1
- Armadura/skill tree por constelação (Fases 2/3), reset raro, textura real da bússola
## Próximos passos
Compilar/testar Fase 1 -> Fase 2 (atributos, Cosmo, menu V)
