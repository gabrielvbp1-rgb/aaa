# Como gerar o .jar (Forge 1.12.2)
O mod precisa ser COMPILADO. Um zip com código não funciona na pasta mods.

1. Instale o JDK 8.
2. Baixe o Forge MDK 1.12.2 (files.minecraftforge.net -> 1.12.2 -> "Mdk"). Extraia.
3. Apague a pasta `src` do MDK e copie a pasta `src` deste projeto no lugar.
4. No `build.gradle` do MDK ajuste: version = "0.1.0", group = "com.saintseiya", archivesBaseName = "saintseiya".
5. No terminal, dentro da pasta do MDK:
   - gradlew setupDecompWorkspace
   - gradlew build
6. O .jar sai em build/libs/. Coloque na pasta mods do Minecraft 1.12.2 com Forge 14.23.5.2860.

Teste: entre num mundo -> abre o menu de iniciação. A aba criativa "Saint Seiya" tem a Bússola.
