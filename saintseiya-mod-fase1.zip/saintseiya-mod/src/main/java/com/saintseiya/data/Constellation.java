package com.saintseiya.data;

/** Constelações de Bronze jogáveis. PROVISÓRIO: lista a ser verificada na pesquisa (ver CHECKLIST.md). */
public enum Constellation {
    PEGASUS("Pégaso"), DRAGON("Dragão"), CYGNUS("Cisne"), ANDROMEDA("Andrômeda"), PHOENIX("Fênix"),
    UNICORN("Unicórnio"), BEAR("Urso"), WOLF("Lobo"), LIONET("Leão Menor"), HYDRA("Hidra");

    public final String displayName;
    Constellation(String n) { displayName = n; }

    public static Constellation byId(int i) {
        return (i >= 0 && i < values().length) ? values()[i] : null;
    }
}
