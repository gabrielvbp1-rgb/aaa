package com.saintseiya.data;

/** Os 12 signos, na ordem tradicional das Casas. */
public enum Zodiac {
    ARIES("Áries"), TAURUS("Touro"), GEMINI("Gêmeos"), CANCER("Câncer"), LEO("Leão"), VIRGO("Virgem"),
    LIBRA("Libra"), SCORPIO("Escorpião"), SAGITTARIUS("Sagitário"), CAPRICORN("Capricórnio"),
    AQUARIUS("Aquário"), PISCES("Peixes");

    public final String displayName;
    Zodiac(String n) { displayName = n; }

    public static Zodiac byId(int i) {
        return (i >= 0 && i < values().length) ? values()[i] : null;
    }
}
