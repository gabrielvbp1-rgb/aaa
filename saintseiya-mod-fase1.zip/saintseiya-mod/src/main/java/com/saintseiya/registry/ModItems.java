package com.saintseiya.registry;

import com.saintseiya.SaintSeiyaMod;
import com.saintseiya.item.ItemSaintCompass;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.item.Item;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@Mod.EventBusSubscriber(modid = SaintSeiyaMod.MODID)
public class ModItems {
    public static final Item SAINT_COMPASS = new ItemSaintCompass();

    @SubscribeEvent
    public static void registerItems(RegistryEvent.Register<Item> e) {
        e.getRegistry().register(SAINT_COMPASS);
    }

    @SubscribeEvent
    @SideOnly(Side.CLIENT)
    public static void registerModels(ModelRegistryEvent e) {
        ModelLoader.setCustomModelResourceLocation(SAINT_COMPASS, 0,
                new ModelResourceLocation(SAINT_COMPASS.getRegistryName(), "inventory"));
    }
}
