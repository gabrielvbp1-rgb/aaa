package com.saintseiya.capability;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityInject;

public class PlayerSaintData {
    @CapabilityInject(PlayerSaintData.class)
    public static Capability<PlayerSaintData> CAP = null;

    private int constellation = -1;
    private int zodiac = -1;
    private boolean chosen = false;

    public int getConstellation() { return constellation; }
    public int getZodiac() { return zodiac; }
    public boolean isChosen() { return chosen; }

    public void set(int c, int z, boolean ch) { constellation = c; zodiac = z; chosen = ch; }
    public void choose(int c, int z) { set(c, z, true); }

    public NBTTagCompound write() {
        NBTTagCompound t = new NBTTagCompound();
        t.setInteger("constellation", constellation);
        t.setInteger("zodiac", zodiac);
        t.setBoolean("chosen", chosen);
        return t;
    }

    public void read(NBTTagCompound t) {
        constellation = t.hasKey("constellation") ? t.getInteger("constellation") : -1;
        zodiac = t.hasKey("zodiac") ? t.getInteger("zodiac") : -1;
        chosen = t.getBoolean("chosen");
    }
}
