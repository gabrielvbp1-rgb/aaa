package com.saintseiya.capability;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumFacing;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ICapabilitySerializable;

public class SaintDataProvider implements ICapabilitySerializable<NBTTagCompound> {
    private final PlayerSaintData data = new PlayerSaintData();

    @Override
    public boolean hasCapability(Capability<?> cap, EnumFacing f) { return cap == PlayerSaintData.CAP; }

    @Override
    public <T> T getCapability(Capability<T> cap, EnumFacing f) {
        return cap == PlayerSaintData.CAP ? PlayerSaintData.CAP.cast(data) : null;
    }

    @Override
    public NBTTagCompound serializeNBT() { return data.write(); }

    @Override
    public void deserializeNBT(NBTTagCompound nbt) { data.read(nbt); }
}
