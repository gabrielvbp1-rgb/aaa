package com.saintseiya.capability;

import com.saintseiya.SaintSeiyaMod;
import com.saintseiya.network.SyncMessage;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class SaintEventHandler {
    @SubscribeEvent
    public void attach(AttachCapabilitiesEvent<Entity> e) {
        if (e.getObject() instanceof EntityPlayer) {
            e.addCapability(new ResourceLocation(SaintSeiyaMod.MODID, "saint_data"), new SaintDataProvider());
        }
    }

    @SubscribeEvent
    public void clone(PlayerEvent.Clone e) {
        PlayerSaintData o = e.getOriginal().getCapability(PlayerSaintData.CAP, null);
        PlayerSaintData n = e.getEntityPlayer().getCapability(PlayerSaintData.CAP, null);
        if (o != null && n != null) n.read(o.write());
    }

    @SubscribeEvent
    public void login(PlayerEvent.PlayerLoggedInEvent e) { sync(e.player); }

    @SubscribeEvent
    public void respawn(PlayerEvent.PlayerRespawnEvent e) { sync(e.player); }

    @SubscribeEvent
    public void dim(PlayerEvent.PlayerChangedDimensionEvent e) { sync(e.player); }

    public static void sync(EntityPlayer p) {
        if (!(p instanceof EntityPlayerMP)) return;
        PlayerSaintData d = p.getCapability(PlayerSaintData.CAP, null);
        if (d != null) SaintSeiyaMod.NET.sendTo(new SyncMessage(d), (EntityPlayerMP) p);
    }
}
