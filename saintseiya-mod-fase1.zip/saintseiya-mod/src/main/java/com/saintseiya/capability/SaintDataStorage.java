package com.saintseiya.capability;

import net.minecraft.nbt.NBTBase;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumFacing;
import net.minecraftforge.common.capabilities.Capability;

public class SaintDataStorage implements Capability.IStorage<PlayerSaintData> {
    @Override
    public NBTBase writeNBT(Capability<PlayerSaintData> cap, PlayerSaintData inst, EnumFacing side) {
        return inst.write();
    }

    @Override
    public void readNBT(Capability<PlayerSaintData> cap, PlayerSaintData inst, EnumFacing side, NBTBase nbt) {
        if (nbt instanceof NBTTagCompound) inst.read((NBTTagCompound) nbt);
    }
}
