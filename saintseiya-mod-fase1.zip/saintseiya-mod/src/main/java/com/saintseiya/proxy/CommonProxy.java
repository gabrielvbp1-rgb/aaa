package com.saintseiya.proxy;

import com.saintseiya.network.SyncMessage;

public class CommonProxy {
    public void handleSync(SyncMessage msg) { }
}
