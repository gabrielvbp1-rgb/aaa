package com.saintseiya.proxy;

import com.saintseiya.capability.PlayerSaintData;
import com.saintseiya.client.gui.GuiInitiation;
import com.saintseiya.network.SyncMessage;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;

public class ClientProxy extends CommonProxy {
    @Override
    public void handleSync(SyncMessage msg) {
        Minecraft mc = Minecraft.getMinecraft();
        mc.addScheduledTask(() -> {
            EntityPlayer p = mc.player;
            if (p == null) return;
            PlayerSaintData d = p.getCapability(PlayerSaintData.CAP, null);
            if (d == null) return;
            d.set(msg.constellation, msg.zodiac, msg.chosen);
            if (!msg.chosen && !(mc.currentScreen instanceof GuiInitiation)) {
                mc.displayGuiScreen(new GuiInitiation());
            }
        });
    }
}
