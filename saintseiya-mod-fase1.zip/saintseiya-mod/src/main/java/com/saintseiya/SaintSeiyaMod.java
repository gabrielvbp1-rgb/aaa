package com.saintseiya;

import com.saintseiya.capability.*;
import com.saintseiya.network.*;
import com.saintseiya.proxy.CommonProxy;
import com.saintseiya.registry.ModItems;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.ItemStack;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@Mod(modid = SaintSeiyaMod.MODID, name = "Saint Seiya: Cosmo Legacy", version = "0.1.0", acceptedMinecraftVersions = "[1.12.2]")
public class SaintSeiyaMod {
    public static final String MODID = "saintseiya";

    @SidedProxy(clientSide = "com.saintseiya.proxy.ClientProxy", serverSide = "com.saintseiya.proxy.CommonProxy")
    public static CommonProxy proxy;

    public static SimpleNetworkWrapper NET;

    /** Aba criativa exclusiva do mod. */
    public static final CreativeTabs TAB = new CreativeTabs("saintseiya") {
        @Override
        @SideOnly(Side.CLIENT)
        public ItemStack createIcon() {
            return new ItemStack(ModItems.SAINT_COMPASS);
        }
    };

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent e) {
        NET = NetworkRegistry.INSTANCE.newSimpleChannel(MODID);
        NET.registerMessage(ChooseMessage.Handler.class, ChooseMessage.class, 0, Side.SERVER);
        NET.registerMessage(SyncMessage.Handler.class, SyncMessage.class, 1, Side.CLIENT);
        CapabilityManager.INSTANCE.register(PlayerSaintData.class, new SaintDataStorage(), PlayerSaintData::new);
        MinecraftForge.EVENT_BUS.register(new SaintEventHandler());
    }
}
