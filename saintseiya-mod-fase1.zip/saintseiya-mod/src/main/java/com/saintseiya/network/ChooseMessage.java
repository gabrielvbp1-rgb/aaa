package com.saintseiya.network;

import com.saintseiya.capability.PlayerSaintData;
import com.saintseiya.capability.SaintEventHandler;
import com.saintseiya.data.Constellation;
import com.saintseiya.data.Zodiac;
import com.saintseiya.registry.ModItems;
import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraft.util.text.TextComponentString;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
import net.minecraftforge.items.ItemHandlerHelper;

/** Cliente -> servidor: escolha de constelação e signo (permanente). */
public class ChooseMessage implements IMessage {
    public int constellation, zodiac;

    public ChooseMessage() { }
    public ChooseMessage(int c, int z) { constellation = c; zodiac = z; }

    @Override public void fromBytes(ByteBuf b) { constellation = b.readInt(); zodiac = b.readInt(); }
    @Override public void toBytes(ByteBuf b) { b.writeInt(constellation); b.writeInt(zodiac); }

    public static class Handler implements IMessageHandler<ChooseMessage, IMessage> {
        @Override
        public IMessage onMessage(ChooseMessage m, MessageContext ctx) {
            EntityPlayerMP p = ctx.getServerHandler().player;
            p.getServerWorld().addScheduledTask(() -> {
                PlayerSaintData d = p.getCapability(PlayerSaintData.CAP, null);
                if (d == null || d.isChosen()) return; // servidor valida: escolha só 1 vez
                Constellation c = Constellation.byId(m.constellation);
                Zodiac z = Zodiac.byId(m.zodiac);
                if (c == null || z == null) return;
                d.choose(c.ordinal(), z.ordinal());
                ItemHandlerHelper.giveItemToPlayer(p, new ItemStack(ModItems.SAINT_COMPASS));
                SaintEventHandler.sync(p);
                p.sendMessage(new TextComponentString("§6Sua constelação protetora: §f" + c.displayName
                        + " §6| Signo: §f" + z.displayName));
            });
            return null;
        }
    }
}
