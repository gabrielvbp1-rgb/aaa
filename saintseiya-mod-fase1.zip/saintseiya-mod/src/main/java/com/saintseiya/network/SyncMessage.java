package com.saintseiya.network;

import com.saintseiya.SaintSeiyaMod;
import com.saintseiya.capability.PlayerSaintData;
import io.netty.buffer.ByteBuf;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

/** Servidor -> cliente: estado do jogador. Se chosen=false o cliente abre o menu de iniciação. */
public class SyncMessage implements IMessage {
    public int constellation, zodiac;
    public boolean chosen;

    public SyncMessage() { }
    public SyncMessage(PlayerSaintData d) {
        constellation = d.getConstellation(); zodiac = d.getZodiac(); chosen = d.isChosen();
    }

    @Override public void fromBytes(ByteBuf b) { constellation = b.readInt(); zodiac = b.readInt(); chosen = b.readBoolean(); }
    @Override public void toBytes(ByteBuf b) { b.writeInt(constellation); b.writeInt(zodiac); b.writeBoolean(chosen); }

    public static class Handler implements IMessageHandler<SyncMessage, IMessage> {
        @Override
        public IMessage onMessage(SyncMessage m, MessageContext ctx) {
            SaintSeiyaMod.proxy.handleSync(m);
            return null;
        }
    }
}
