package com.saintseiya.client.gui;

import com.saintseiya.SaintSeiyaMod;
import com.saintseiya.data.Constellation;
import com.saintseiya.data.Zodiac;
import com.saintseiya.network.ChooseMessage;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;

import java.io.IOException;

/** Menu de iniciação: constelação de Bronze + signo. Não fecha com ESC (escolha permanente). */
public class GuiInitiation extends GuiScreen {
    private int selC = -1, selZ = -1;
    private GuiButton confirm;

    @Override
    public void initGui() {
        buttonList.clear();
        int left = width / 2 - 210, right = width / 2 + 10, y0 = 62;
        Constellation[] cs = Constellation.values();
        for (int i = 0; i < cs.length; i++) {
            buttonList.add(new GuiButton(i, left + (i % 2) * 102, y0 + (i / 2) * 22, 100, 20, cs[i].displayName));
        }
        Zodiac[] zs = Zodiac.values();
        for (int i = 0; i < zs.length; i++) {
            buttonList.add(new GuiButton(100 + i, right + (i % 2) * 102, y0 + (i / 2) * 22, 100, 20, zs[i].displayName));
        }
        confirm = new GuiButton(200, width / 2 - 80, y0 + 6 * 22 + 12, 160, 20, "Confirmar (permanente)");
        confirm.enabled = false;
        buttonList.add(confirm);
        refresh();
    }

    private void refresh() {
        for (GuiButton b : buttonList) {
            if (b.id < 100) b.displayString = (b.id == selC ? "§a> " : "") + Constellation.values()[b.id].displayName;
            else if (b.id < 200) b.displayString = (b.id - 100 == selZ ? "§a> " : "") + Zodiac.values()[b.id - 100].displayName;
        }
        confirm.enabled = selC >= 0 && selZ >= 0;
    }

    @Override
    protected void actionPerformed(GuiButton b) throws IOException {
        if (b.id < 100) selC = b.id;
        else if (b.id < 200) selZ = b.id - 100;
        else if (b.id == 200 && selC >= 0 && selZ >= 0) {
            SaintSeiyaMod.NET.sendToServer(new ChooseMessage(selC, selZ));
            mc.displayGuiScreen(null);
            return;
        }
        refresh();
    }

    @Override
    protected void keyTyped(char c, int key) throws IOException { /* ESC bloqueado */ }

    @Override
    public boolean doesGuiPauseGame() { return false; }

    @Override
    public void drawScreen(int mx, int my, float pt) {
        drawDefaultBackground();
        drawCenteredString(fontRenderer, "§6Iniciação do Cavaleiro", width / 2, 20, 0xFFFFFF);
        drawCenteredString(fontRenderer, "Escolha sua constelação de Bronze e seu signo. Essa escolha é permanente.", width / 2, 36, 0xCCCCCC);
        drawString(fontRenderer, "Constelação", width / 2 - 210, 50, 0xFFD700);
        drawString(fontRenderer, "Signo", width / 2 + 10, 50, 0xFFD700);
        super.drawScreen(mx, my, pt);
    }
}
