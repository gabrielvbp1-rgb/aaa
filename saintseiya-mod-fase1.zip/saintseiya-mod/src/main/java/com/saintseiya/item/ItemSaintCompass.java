package com.saintseiya.item;

import com.saintseiya.SaintSeiyaMod;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;

public class ItemSaintCompass extends Item {
    public ItemSaintCompass() {
        setRegistryName(SaintSeiyaMod.MODID, "saint_compass");
        setUnlocalizedName(SaintSeiyaMod.MODID + ".saint_compass");
        setCreativeTab(SaintSeiyaMod.TAB);
        setMaxStackSize(1);
    }

    @Override
    public ActionResult<ItemStack> onItemRightClick(World w, EntityPlayer p, EnumHand h) {
        if (!w.isRemote) {
            p.sendMessage(new TextComponentString("§eA bússola ainda não encontra estruturas (Coliseu, Torre de Jamiel e Santuário chegam nas próximas fases)."));
        }
        return new ActionResult<>(EnumActionResult.SUCCESS, p.getHeldItem(h));
    }
}
